<?php use \App\Support\SafeRoute; ?>
<?php use \App\Support\Site; ?>
<?php
  $applyUrl = SafeRoute::exists('apply') ? route('apply', ['job' => $job->slug]) : '#';
?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => $job->title,'crumbs' => [['Jobs', route('jobs')], [$job->title, null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->title),'crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Jobs', route('jobs')], [$job->title, null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto grid w-[92%] max-w-6xl gap-10 lg:grid-cols-[1.7fr_1fr]">
      <div class="space-y-10">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($closed): ?>
          <div class="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-800">This opening is closed (last date was <?php echo e($job->deadline->format('d M Y')); ?>). Contact us to ask about similar jobs.</div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="reveal">
          <h2 class="mb-4 text-2xl font-bold text-pk-dark"><?php echo e($job->title); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($job->country): ?> – <?php echo e($job->country->name); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></h2>
          <p class="whitespace-pre-line text-slate-600"><?php echo e($job->description ?: $job->summary); ?></p>
        </div>

        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'Requirements','text' => $job->requirements]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Requirements','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->requirements)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'Salary and Benefits','text' => $job->benefits]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Salary and Benefits','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->benefits)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.steps','data' => ['title' => 'How to Apply','steps' => [
          ['Apply', 'Submit the online form'],
          ['Selection', 'Interview or trade test'],
          ['Process', 'Visa and medical'],
          ['Fly', 'Travel and start work'],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'How to Apply','steps' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
          ['Apply', 'Submit the online form'],
          ['Selection', 'Interview or trade test'],
          ['Process', 'Visa and medical'],
          ['Fly', 'Travel and start work'],
        ])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $attributes = $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $component = $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
      </div>

      <aside class="space-y-6">
        <div class="rounded-2xl bg-white p-6 shadow-lg shadow-green-900/10">
          <h3 class="mb-2 font-semibold text-pk-dark">Quick Info</h3>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Position','value' => $job->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Position','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->title)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Country','value' => $job->country?->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Country','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->country?->name)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Category','value' => $job->category]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Category','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->category)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Salary','value' => $salary ?? 'As per contract']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Salary','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salary ?? 'As per contract')]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Vacancies','value' => $job->vacancies]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Vacancies','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->vacancies)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Last date','value' => $job->deadline?->format('d M Y')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Last date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->deadline?->format('d M Y'))]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($closed): ?>
          <div class="rounded-2xl bg-gradient-to-br from-pk-green to-pk-dark p-6 text-white shadow-xl">
            <h3 class="mb-2 text-lg font-semibold">Applications closed</h3>
            <p class="mb-4 text-sm text-green-100">Ask us about other openings.<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone()): ?> 📞 <a href="<?php echo e(Site::phoneHref()); ?>" class="font-semibold hover:underline"><?php echo e(Site::phone()); ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></p>
            <a href="<?php echo e(SafeRoute::url('contact')); ?>" class="btn btn-red block text-center">Contact Us</a>
          </div>
        <?php else: ?>
          <div class="rounded-2xl bg-gradient-to-br from-pk-green to-pk-dark p-6 text-white shadow-xl">
            <h3 class="mb-2 text-lg font-semibold">Need help?</h3>
            <p class="mb-4 text-sm text-green-100">Our team will explain everything clearly.<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone()): ?> 📞 <a href="<?php echo e(Site::phoneHref()); ?>" class="font-semibold hover:underline"><?php echo e(Site::phone()); ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></p>
            <a href="<?php echo e($applyUrl); ?>" class="btn btn-red mb-3 block text-center">Apply for This Job</a>
            <a href="<?php echo e(SafeRoute::url('contact')); ?>" class="btn btn-line block text-center">Contact Us</a>
          </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </aside>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal106c39dd228b3992904670768e42d9e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal106c39dd228b3992904670768e42d9e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.cta','data' => ['title' => 'Not the Right Job?','text' => 'Tell us your skills and we will find a better match.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Not the Right Job?','text' => 'Tell us your skills and we will find a better match.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $attributes = $__attributesOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__attributesOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $component = $__componentOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__componentOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/jobs/show.blade.php ENDPATH**/ ?>