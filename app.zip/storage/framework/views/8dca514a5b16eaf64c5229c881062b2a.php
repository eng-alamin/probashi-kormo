<div>
  <div class="page-head">
    <div><h2>Roles &amp; Permissions</h2><p>What each role is allowed to do in the admin panel</p></div>
  </div>

  <div class="glass panel">
    <div class="table-wrap">
      <table class="responsive-table">
        <thead>
          <tr>
            <th scope="col">Role</th>
            <th scope="col">People</th>
            <th scope="col">Permissions</th>
            <th scope="col"><span class="sr-only">Actions</span></th>
          </tr>
        </thead>
        <tbody>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php
              $isSuper = $role->name === 'Super Admin';
              $pill = match ($role->name) { 'Super Admin' => 'role-super', 'Admin' => 'role-support', default => 'role-billing' };
            ?>
            <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'role-'.e($role->id).''; ?>wire:key="role-<?php echo e($role->id); ?>">
              <td class="cell-main-td"><span class="role-pill <?php echo e($pill); ?>"><?php echo e($role->name); ?></span></td>
              <td data-label="People"><?php echo e($role->users_count); ?></td>
              <td data-label="Permissions">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isSuper): ?>
                  Everything (cannot be changed)
                <?php else: ?>
                  <?php echo e($role->permissions_count); ?> of <?php echo e($totalPermissions); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </td>
              <td>
                <div class="row-actions">
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isSuper): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.roles.edit', $role)); ?>" aria-label="Edit <?php echo e($role->name); ?> permissions"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
              </td>
            </tr>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
      </table>
    </div>
    <p class="form-hint" style="margin-top:14px;">The three roles are fixed. Change what Admin and Staff can do by editing their permissions. Give a person a role on the Staff Users page.</p>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/roles/index.blade.php ENDPATH**/ ?>