<?php use \App\Support\SafeRoute; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => 'Our Services','crumbs' => [['Services', null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Our Services','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Services', null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="reveal mx-auto w-[92%] max-w-6xl text-center">
      <span class="eyebrow">What We Do</span>
      <h2 class="title">Everything You Need to Work Abroad</h2>
      <p class="lead mx-auto">One agency, one team — from your first training class to your flight.</p>
      <div class="mt-11 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <a href="<?php echo e(route('services.show', $service)); ?>" class="card block">
            <div class="mb-3 text-4xl"><?php echo e($service->icon); ?></div>
            <h3 class="mb-2 text-lg font-semibold text-pk-dark"><?php echo e($service->title); ?></h3>
            <p class="text-[.95rem] text-slate-600"><?php echo e($service->summary); ?></p>
            <span class="mt-3 inline-block text-sm font-semibold text-pk-red">Learn more →</span>
          </a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          <p class="col-span-full text-slate-500">Services will be listed here soon.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </div>
  </section>

  <section class="bg-pk-bg py-16 md:py-20">
    <div class="reveal mx-auto w-[92%] max-w-6xl text-center">
      <span class="eyebrow">How It Works</span>
      <h2 class="title">Simple 4-Step Process</h2>
      <div class="mt-11">
        <?php if (isset($component)) { $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.steps','data' => ['steps' => [
          ['Registration', 'Submit documents and choose your trade.'],
          ['Training', 'Complete skill training at our center.'],
          ['Visa & Medical', 'We process visa, medical and clearance.'],
          ['Departure', 'Fly to your job with full support.'],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['steps' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
          ['Registration', 'Submit documents and choose your trade.'],
          ['Training', 'Complete skill training at our center.'],
          ['Visa & Medical', 'We process visa, medical and clearance.'],
          ['Departure', 'Fly to your job with full support.'],
        ])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $attributes = $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $component = $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
      </div>
    </div>
  </section>

  <section class="py-16 md:py-20">
    <div class="mx-auto w-[92%] max-w-3xl">
      <div class="mb-10 text-center">
        <span class="eyebrow">FAQ</span>
        <h2 class="title">Frequently Asked Questions</h2>
      </div>
      <?php if (isset($component)) { $__componentOriginal7073e2c1ecf60a5064d36e22ed85649b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7073e2c1ecf60a5064d36e22ed85649b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.faq','data' => ['title' => '','items' => [
        ['What documents do I need to start?', 'Usually a valid passport, national ID, passport-size photos and educational or skill certificates if you have them. Our team will confirm the exact list for your job.'],
        ['How long does the whole process take?', 'It depends on the country, the job and visa processing time. We will give you an honest estimate before you begin.'],
        ['Is training required before going abroad?', 'For most skilled jobs, yes. Training improves your chances of selection and helps you work confidently from day one.'],
        ['What is the total cost?', 'The cost depends on the country and job. We explain every cost clearly in advance, with no hidden charges.'],
      ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.faq'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => '','items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        ['What documents do I need to start?', 'Usually a valid passport, national ID, passport-size photos and educational or skill certificates if you have them. Our team will confirm the exact list for your job.'],
        ['How long does the whole process take?', 'It depends on the country, the job and visa processing time. We will give you an honest estimate before you begin.'],
        ['Is training required before going abroad?', 'For most skilled jobs, yes. Training improves your chances of selection and helps you work confidently from day one.'],
        ['What is the total cost?', 'The cost depends on the country and job. We explain every cost clearly in advance, with no hidden charges.'],
      ])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7073e2c1ecf60a5064d36e22ed85649b)): ?>
<?php $attributes = $__attributesOriginal7073e2c1ecf60a5064d36e22ed85649b; ?>
<?php unset($__attributesOriginal7073e2c1ecf60a5064d36e22ed85649b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7073e2c1ecf60a5064d36e22ed85649b)): ?>
<?php $component = $__componentOriginal7073e2c1ecf60a5064d36e22ed85649b; ?>
<?php unset($__componentOriginal7073e2c1ecf60a5064d36e22ed85649b); ?>
<?php endif; ?>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal106c39dd228b3992904670768e42d9e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal106c39dd228b3992904670768e42d9e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.cta','data' => ['title' => 'Have a Question? Ask Us.','text' => 'Our team will explain jobs, requirements and costs clearly.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Have a Question? Ask Us.','text' => 'Our team will explain jobs, requirements and costs clearly.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $attributes = $__attributesOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__attributesOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $component = $__componentOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__componentOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/services/index.blade.php ENDPATH**/ ?>