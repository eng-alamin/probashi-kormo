<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => $course->title,'crumbs' => [['Training', route('training')], [$course->title, null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->title),'crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Training', route('training')], [$course->title, null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto grid w-[92%] max-w-6xl gap-10 lg:grid-cols-[1.7fr_1fr]">
      <div class="space-y-10">
        <div class="reveal">
          <div class="mb-4 text-6xl"><?php echo e($course->icon); ?></div>
          <h2 class="mb-4 text-2xl font-bold text-pk-dark"><?php echo e($course->title); ?> Course</h2>
          <p class="text-slate-600"><?php echo e($course->description ?: $course->summary); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'What You Will Learn','text' => $course->learn_points]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'What You Will Learn','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->learn_points)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'Where You Can Work Abroad','text' => $course->career_points]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Where You Can Work Abroad','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->career_points)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'Who Can Join','text' => $course->eligibility]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Who Can Join','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->eligibility)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.steps','data' => ['title' => 'Training Path','steps' => [
          ['Join', 'Register and choose your trade'],
          ['Learn', 'Theory and hands-on practice'],
          ['Test', 'Skill test and evaluation'],
          ['Get Placed', 'Apply for overseas jobs'],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Training Path','steps' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
          ['Join', 'Register and choose your trade'],
          ['Learn', 'Theory and hands-on practice'],
          ['Test', 'Skill test and evaluation'],
          ['Get Placed', 'Apply for overseas jobs'],
        ])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $attributes = $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $component = $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
      </div>
      <aside class="space-y-6">
        <div class="rounded-2xl bg-white p-6 shadow-lg shadow-green-900/10">
          <h3 class="mb-2 font-semibold text-pk-dark">Quick Info</h3>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Course','value' => $course->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Course','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->title)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Duration','value' => $course->duration_weeks ? $course->duration_weeks.' weeks' : null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Duration','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->duration_weeks ? $course->duration_weeks.' weeks' : null)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Class days','value' => $course->class_days]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Class days','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->class_days)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Course fee','value' => $course->fee ? '৳ '.number_format($course->fee) : null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Course fee','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->fee ? '৳ '.number_format($course->fee) : null)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Certificate','value' => $course->certificate_info]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Certificate','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($course->certificate_info)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.help-box','data' => ['apply' => 'Join This Course']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.help-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['apply' => 'Join This Course']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $attributes = $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $component = $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
      </aside>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal8e9a093eefd41e45845394149ea14be9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e9a093eefd41e45845394149ea14be9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.chips','data' => ['title' => 'Other Courses','route' => 'training.show','items' => $others->map(fn ($c) => [$c->icon.' '.$c->title, $c->slug])->all()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.chips'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Other Courses','route' => 'training.show','items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($others->map(fn ($c) => [$c->icon.' '.$c->title, $c->slug])->all())]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $attributes = $__attributesOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__attributesOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $component = $__componentOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__componentOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal106c39dd228b3992904670768e42d9e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal106c39dd228b3992904670768e42d9e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.cta','data' => ['title' => 'Ready to Start?','text' => 'Ask about the next batch and how to join.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Ready to Start?','text' => 'Ask about the next batch and how to join.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $attributes = $__attributesOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__attributesOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $component = $__componentOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__componentOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/training/show.blade.php ENDPATH**/ ?>