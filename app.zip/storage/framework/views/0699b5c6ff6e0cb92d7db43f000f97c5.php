<?php use \App\Support\Phone; ?>
<div>
  <div class="page-head">
    <div>
      <h2><?php echo e($application->full_name); ?></h2>
      <p>Applied <?php echo e($application->created_at->format('d M Y, h:i A')); ?></p>
    </div>
    <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-ghost btn-sm"><i class="bi bi-arrow-left" aria-hidden="true"></i> Back</a>
  </div>

  <div class="grid-2">
    <div class="glass panel">
      <div class="panel-title"><h5>Applicant details</h5></div>
      <div class="detail-row"><span class="k">Phone</span><span><a href="tel:<?php echo e($application->phone); ?>"><?php echo e($application->phone); ?></a> · <a href="<?php echo e(Phone::whatsappUrl($application->phone)); ?>" target="_blank" rel="noopener">WhatsApp</a></span></div>
      <div class="detail-row"><span class="k">Age</span><span><?php echo e($application->age ?? '—'); ?></span></div>
      <div class="detail-row"><span class="k">District</span><span><?php echo e($application->district ?: '—'); ?></span></div>
      <div class="detail-row"><span class="k">Passport</span><span><?php echo e($application->passport_status->label()); ?></span></div>
      <div class="detail-row"><span class="k">Education</span><span><?php echo e($application->education ?: '—'); ?></span></div>
      <div class="detail-row"><span class="k">Experience</span><span><?php echo e($application->experience ?: '—'); ?></span></div>
      <div class="detail-row"><span class="k">Job</span><span><?php echo e($application->jobPost?->title ?? '—'); ?></span></div>
      <div class="detail-row"><span class="k">Trade</span><span><?php echo e($application->trade ?: '—'); ?></span></div>
      <div class="detail-row"><span class="k">Country</span><span><?php echo e($application->country?->name ?? '—'); ?></span></div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($application->message): ?>
        <div class="detail-row" style="flex-direction:column;"><span class="k">Message</span><span class="note-text"><?php echo e($application->message); ?></span></div>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="glass panel">
      <div class="panel-title"><h5>Follow-up</h5></div>
      <form wire:submit="save" novalidate>
        <div class="mb-3">
          <label class="form-label" for="status">Status</label>
          <select id="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="status" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('applications.update')): ?> disabled <?php endif; ?>>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <option value="<?php echo e($s->value); ?>"><?php echo e($s->label()); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </select>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="field-error show" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label" for="admin_note">Internal note</label>
          <textarea id="admin_note" rows="5" class="form-control <?php $__errorArgs = ['admin_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="admin_note" maxlength="2000" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('applications.update')): ?> disabled <?php endif; ?>></textarea>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['admin_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="field-error show" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($application->handledBy): ?>
          <p class="cell-sub" style="margin-bottom:14px;">Last handled by <?php echo e($application->handledBy->name); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applications.update')): ?>
          <button type="submit" class="btn btn-cobalt" wire:loading.attr="disabled" wire:target="save">
            <span wire:loading.remove wire:target="save">Save</span>
            <span wire:loading wire:target="save">Saving…</span>
          </button>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('applications.delete')): ?>
          <button type="button" class="btn btn-danger" wire:click="$set('confirmingDelete', true)">Delete</button>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="modal-overlay <?php echo e($confirmingDelete ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $confirmingDelete): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this application?</h4>
      <p class="modal-sub">This cannot be undone.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="$set('confirmingDelete', false)">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/applications/show.blade.php ENDPATH**/ ?>