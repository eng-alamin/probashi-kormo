<?php use \App\Support\Lines; ?>
<?php use \App\Support\SafeRoute; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => $country->name,'crumbs' => [['Countries', route('countries')], [$country->name, null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country->name),'crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Countries', route('countries')], [$country->name, null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto grid w-[92%] max-w-6xl gap-10 lg:grid-cols-[1.7fr_1fr]">
      <div class="space-y-10">
        <div class="reveal">
          <div class="mb-4 text-6xl"><?php echo e($country->flag); ?></div>
          <h2 class="mb-4 text-2xl font-bold text-pk-dark">Working in <?php echo e($country->name); ?></h2>
          <p class="text-slate-600"><?php echo e($country->description ?: $country->summary); ?></p>
        </div>

        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'Common Job Sectors','text' => $country->job_sectors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Common Job Sectors','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country->job_sectors)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>

        <div class="reveal">
          <h2 class="mb-4 text-2xl font-bold text-pk-dark">Documents Usually Needed</h2>
          <ul class="space-y-2.5">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['Valid passport', 'National ID card', 'Recent passport-size photos', 'Educational or skill certificates, if you have them', 'Medical report and clearance, as required', 'Any other document needed for your specific job']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <li class="relative pl-7 before:absolute before:left-0 before:text-pk-red before:content-['✔']"><?php echo e($doc); ?></li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </ul>
          <p class="mt-3 text-sm text-slate-500">Our team confirms the exact list for your job and country.</p>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($country->extra_info)): ?>
          <div class="reveal rounded-2xl bg-pk-bg p-6">
            <h3 class="mb-2 font-semibold text-pk-dark">Country-specific information</h3>
            <p class="whitespace-pre-line text-sm text-slate-600"><?php echo e($country->extra_info); ?></p>
          </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.steps','data' => ['title' => 'How It Works','steps' => [
          ['Choose Country', 'Tell us your preferred destination and job.'],
          ['Check Demand', 'We share jobs and requirements.'],
          ['Process Documents', 'Visa, medical and clearance with our help.'],
          ['Fly & Work', 'Travel with full support.'],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'How It Works','steps' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
          ['Choose Country', 'Tell us your preferred destination and job.'],
          ['Check Demand', 'We share jobs and requirements.'],
          ['Process Documents', 'Visa, medical and clearance with our help.'],
          ['Fly & Work', 'Travel with full support.'],
        ])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $attributes = $__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__attributesOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7)): ?>
<?php $component = $__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7; ?>
<?php unset($__componentOriginal4f5b9fb67cdfce8eefbff663a73c6da7); ?>
<?php endif; ?>

        <div class="reveal">
          <h2 class="mb-4 text-2xl font-bold text-pk-dark">Frequently Asked Questions</h2>
          <div class="space-y-4">
            <details class="group rounded-xl bg-white p-5 shadow-lg shadow-green-900/10">
              <summary class="flex cursor-pointer list-none items-center justify-between font-semibold text-pk-dark">Which jobs are available now?<span class="text-pk-red transition group-open:rotate-45">+</span></summary>
              <p class="mt-3 text-sm text-slate-600">Openings change often. Please check our <a href="<?php echo e(SafeRoute::url('jobs')); ?>" class="font-semibold text-pk-red">Jobs page</a> or contact us for the latest list.</p>
            </details>
            <details class="group rounded-xl bg-white p-5 shadow-lg shadow-green-900/10">
              <summary class="flex cursor-pointer list-none items-center justify-between font-semibold text-pk-dark">Do I need training first?<span class="text-pk-red transition group-open:rotate-45">+</span></summary>
              <p class="mt-3 text-sm text-slate-600">For most skilled jobs, trained workers are preferred. See our <a href="<?php echo e(SafeRoute::url('training')); ?>" class="font-semibold text-pk-red">training courses</a>.</p>
            </details>
            <details class="group rounded-xl bg-white p-5 shadow-lg shadow-green-900/10">
              <summary class="flex cursor-pointer list-none items-center justify-between font-semibold text-pk-dark">How much will it cost?<span class="text-pk-red transition group-open:rotate-45">+</span></summary>
              <p class="mt-3 text-sm text-slate-600">The cost depends on the job. We explain every cost clearly before you begin, with no hidden charges.</p>
            </details>
          </div>
        </div>
      </div>

      <aside class="space-y-6">
        <div class="rounded-2xl bg-white p-6 shadow-lg shadow-green-900/10">
          <h3 class="mb-2 font-semibold text-pk-dark">Quick Info</h3>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Country','value' => $country->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Country','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country->name)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Job sectors','value' => count(Lines::split($country->job_sectors)) ? count(Lines::split($country->job_sectors)).' main sectors' : null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Job sectors','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count(Lines::split($country->job_sectors)) ? count(Lines::split($country->job_sectors)).' main sectors' : null)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Salary','value' => 'As per contract']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Salary','value' => 'As per contract']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Contract','value' => $country->contract_info]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Contract','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country->contract_info)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.help-box','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.help-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $attributes = $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $component = $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
      </aside>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal8e9a093eefd41e45845394149ea14be9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e9a093eefd41e45845394149ea14be9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.chips','data' => ['title' => 'Other Countries','route' => 'countries.show','items' => $others->map(fn ($c) => [$c->flag.' '.$c->name, $c->slug])->all()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.chips'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Other Countries','route' => 'countries.show','items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($others->map(fn ($c) => [$c->flag.' '.$c->name, $c->slug])->all())]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $attributes = $__attributesOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__attributesOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $component = $__componentOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__componentOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal106c39dd228b3992904670768e42d9e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal106c39dd228b3992904670768e42d9e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.cta','data' => ['title' => 'Find Your Job in '.$country->name,'text' => 'Ask us about the latest openings.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Find Your Job in '.$country->name),'text' => 'Ask us about the latest openings.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $attributes = $__attributesOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__attributesOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $component = $__componentOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__componentOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/countries/show.blade.php ENDPATH**/ ?>