<div>
  <div class="page-head">
    <div><h2>Staff Users</h2><p>People who can sign in to this admin panel</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>
      <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New staff user</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search name or email" aria-label="Search staff">
      </label>
      <select class="form-select" wire:model.live="role" aria-label="Filter by role">
        <option value="">All roles</option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $roleNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <option value="<?php echo e($r); ?>"><?php echo e($r); ?></option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </select>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($users->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-people-fill"></i></div>
        <h6>No staff found</h6>
        <p>Try a different search.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Person</th>
              <th scope="col">Role</th>
              <th scope="col">Active</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <?php
                $roleName = (string) $u->roles->first()?->name;
                $isMe = $u->is(auth()->user());
                $manageable = \App\Support\StaffAccess::canManage(auth()->user(), $u);
                $pill = match ($roleName) { 'Super Admin' => 'role-super', 'Admin' => 'role-support', default => 'role-billing' };
              ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'user-'.e($u->id).''; ?>wire:key="user-<?php echo e($u->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <span class="cell-avatar" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($u->name, 0, 1))); ?></span>
                    <div>
                      <div class="cell-title"><?php echo e($u->name); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isMe): ?> <span class="plan-tag">You</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                      <div class="cell-sub"><?php echo e($u->email); ?></div>
                    </div>
                  </div>
                </td>
                <td data-label="Role"><span class="role-pill <?php echo e($pill); ?>"><?php echo e($roleName ?: 'No role'); ?></span></td>
                <td data-label="Active">
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($manageable && ! $isMe): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update')): ?>
                      <button type="button" class="status-toggle" wire:click="toggleActive(<?php echo e($u->id); ?>)" role="switch" aria-checked="<?php echo e($u->is_active ? 'true' : 'false'); ?>" aria-label="Account active for <?php echo e($u->name); ?>"><span class="switch <?php echo e($u->is_active ? 'on' : ''); ?>"></span></button>
                    <?php else: ?>
                      <?php echo e($u->is_active ? 'Yes' : 'No'); ?>

                    <?php endif; ?>
                  <?php else: ?>
                    <?php echo e($u->is_active ? 'Yes' : 'No'); ?>

                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($manageable): ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.update')): ?>
                        <a class="icon-action" href="<?php echo e(route('admin.users.edit', $u)); ?>" aria-label="Edit <?php echo e($u->name); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                      <?php endif; ?>
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isMe): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete')): ?>
                          <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($u->id); ?>)" aria-label="Delete <?php echo e($u->name); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                        <?php endif; ?>
                      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($users->links('pagination.admin')); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this account?</h4>
      <p class="modal-sub">They can no longer sign in. To stop access but keep the record, switch Active off instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/users/index.blade.php ENDPATH**/ ?>