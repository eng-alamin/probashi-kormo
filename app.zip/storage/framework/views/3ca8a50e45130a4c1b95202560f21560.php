<?php use \App\Support\SafeRoute; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => 'Terms & Conditions','crumbs' => [['Terms & Conditions', null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Terms & Conditions','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Terms & Conditions', null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<section class="py-16 md:py-20"><div class="mx-auto w-[92%] max-w-3xl">
  <h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Use of this website</h2><p class="text-slate-600">The information on this website is provided in good faith. Job availability, requirements and costs can change at any time.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">No guarantee</h2><p class="text-slate-600">Submitting a form on this website does not guarantee a job or visa. Selection depends on the employer and the authorities.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Fees</h2><p class="text-slate-600">We explain all fees clearly before you proceed. Please always get a proper receipt for any payment.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Accuracy of your information</h2><p class="text-slate-600">You are responsible for giving true and complete information and documents.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Contact</h2><p class="text-slate-600">For any question about these terms, contact us at info@probashikormo.com.</p>
</div></section>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/terms.blade.php ENDPATH**/ ?>