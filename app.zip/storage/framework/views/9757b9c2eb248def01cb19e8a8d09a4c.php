<?php use \App\Support\SafeRoute; ?>
<nav class="sidebar" id="sidebar" aria-label="Main navigation">
  <a href="<?php echo e(SafeRoute::url('admin.dashboard')); ?>" class="brand"><span class="dot" aria-hidden="true"></span><span class="nav-label"><?php echo e(config('site.short_name')); ?></span></a>
  <div class="nav-scroll">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = config('admin_menu.sections'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
      <div class="nav-section-label"><?php echo e($section['label']); ?></div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
      <?php if(! empty($item['can']) && ! auth()->user()?->can($item['can'])): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php continue; ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(SafeRoute::exists($item['route'])): ?>
          <?php ($active = request()->routeIs($item['match'] ?? $item['route'])); ?>
          <a class="nav-item <?php echo e($active ? 'active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>" title="<?php echo e($item['label']); ?>" <?php if($active): ?> aria-current="page" <?php endif; ?>>
            <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i><span class="nav-label"><?php echo e($item['label']); ?></span>
          </a>
        <?php else: ?>
          <span class="nav-item is-disabled" title="<?php echo e($item['label']); ?> (coming soon)" aria-disabled="true">
            <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i><span class="nav-label"><?php echo e($item['label']); ?><small class="nav-soon">Soon</small></span>
          </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    <div class="sidebar-foot">
      <a class="nav-item" href="<?php echo e(SafeRoute::url('home')); ?>" target="_blank" rel="noopener" title="View website">
        <i class="bi bi-box-arrow-up-right" aria-hidden="true"></i><span class="nav-label">View website</span>
      </a>
    </div>
  </div>
</nav>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/layouts/partials/admin-sidebar.blade.php ENDPATH**/ ?>