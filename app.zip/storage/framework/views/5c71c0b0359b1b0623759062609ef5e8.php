<?php use \App\Support\Phone; ?>
<div>
  <div class="page-head">
    <div>
      <h2><?php echo e($inquiry->full_name); ?></h2>
      <p>Received <?php echo e($inquiry->created_at->format('d M Y, h:i A')); ?></p>
    </div>
    <a href="<?php echo e(route('admin.inquiries.index')); ?>" class="btn btn-ghost btn-sm"><i class="bi bi-arrow-left" aria-hidden="true"></i> Back</a>
  </div>

  <div class="grid-2">
    <div class="glass panel">
      <div class="panel-title"><h5>Message</h5></div>
      <div class="detail-row"><span class="k">Phone</span><span><a href="tel:<?php echo e($inquiry->phone); ?>"><?php echo e($inquiry->phone); ?></a> · <a href="<?php echo e(Phone::whatsappUrl($inquiry->phone)); ?>" target="_blank" rel="noopener">WhatsApp</a></span></div>
      <div class="detail-row"><span class="k">Country</span><span><?php echo e($inquiry->country?->name ?? '—'); ?></span></div>
      <div class="detail-row"><span class="k">Trade</span><span><?php echo e($inquiry->trade ?: '—'); ?></span></div>
      <div class="detail-row" style="flex-direction:column;"><span class="k">Message</span><span class="note-text"><?php echo e($inquiry->message); ?></span></div>
    </div>

    <div class="glass panel">
      <div class="panel-title"><h5>Status</h5></div>
      <form wire:submit="save" novalidate>
        <div class="mb-3">
          <label class="form-label" for="status">Status</label>
          <select id="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="status" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('inquiries.update')): ?> disabled <?php endif; ?>>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <option value="<?php echo e($s->value); ?>"><?php echo e($s->label()); ?></option>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </select>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="field-error show" role="alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inquiries.update')): ?>
          <button type="submit" class="btn btn-cobalt" wire:loading.attr="disabled" wire:target="save">
            <span wire:loading.remove wire:target="save">Save</span>
            <span wire:loading wire:target="save">Saving…</span>
          </button>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inquiries.delete')): ?>
          <button type="button" class="btn btn-danger" wire:click="$set('confirmingDelete', true)">Delete</button>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="modal-overlay <?php echo e($confirmingDelete ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $confirmingDelete): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this inquiry?</h4>
      <p class="modal-sub">This cannot be undone.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="$set('confirmingDelete', false)">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/inquiries/show.blade.php ENDPATH**/ ?>