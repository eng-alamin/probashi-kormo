<?php use \App\Support\Site; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => 'Contact Us','crumbs' => [['Contact', null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Contact Us','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Contact', null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto grid w-[92%] max-w-6xl gap-10 lg:grid-cols-[1fr_1.1fr]">
      <div>
        <span class="eyebrow">Get in Touch</span>
        <h2 class="title">We Are Happy to Help</h2>
        <p class="lead mb-6">Visit our office, call us, or send a message. We will explain jobs, requirements and costs clearly.</p>
        <div class="space-y-4">
          <?php
            $cards = [
              ['📍', 'Office Address', Site::address()],
              ['📞', 'Phone', Site::phone()],
              ['✉️', 'Email', Site::email()],
              ['🕒', 'Office Hours', Site::hours()],
            ];
          ?>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$icon, $heading, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($value)): ?>
              <div class="flex gap-4 rounded-2xl bg-white p-5 shadow-lg shadow-green-900/10">
                <div class="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-pk-green/10 text-2xl"><?php echo e($icon); ?></div>
                <div><h3 class="font-semibold text-pk-dark"><?php echo e($heading); ?></h3><p class="text-sm text-slate-600"><?php echo e($value); ?></p></div>
              </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
        <a href="<?php echo e(config('site.facebook')); ?>" target="_blank" rel="noopener" class="btn btn-green mt-6">Visit Our Facebook Page</a>
      </div>

      <div class="rounded-2xl bg-white p-6 shadow-xl shadow-green-900/10 md:p-8">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sent): ?>
          <div class="py-6 text-center">
            <div class="mb-3 text-6xl">✅</div>
            <h3 class="mb-2 text-xl font-semibold text-pk-dark">Message Sent</h3>
            <p class="text-sm text-slate-600">Thank you. Our team will contact you soon on the phone number you gave.</p>
          </div>
        <?php else: ?>
          <h3 class="mb-1 text-xl font-semibold text-pk-dark">Send Us a Message</h3>
          <p class="mb-5 text-sm text-slate-500">We will reply on your phone number.</p>
          <form wire:submit="submit" class="space-y-4">
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Full Name','model' => 'form.full_name','required' => true,'placeholder' => 'Your name','autocomplete' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Full Name','model' => 'form.full_name','required' => true,'placeholder' => 'Your name','autocomplete' => 'name']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Phone Number','model' => 'form.phone','type' => 'tel','required' => true,'placeholder' => '01XXXXXXXXX','autocomplete' => 'tel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Phone Number','model' => 'form.phone','type' => 'tel','required' => true,'placeholder' => '01XXXXXXXXX','autocomplete' => 'tel']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
            <div class="grid gap-4 sm:grid-cols-2">
              <?php if (isset($component)) { $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.select','data' => ['label' => 'Preferred Country','model' => 'form.country_id','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Preferred Country','model' => 'form.country_id','required' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

                <option value="">Select country</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                  <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <option value="other">Other / Not sure</option>
               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $attributes = $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $component = $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
              <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Trade / Job','model' => 'form.trade','placeholder' => 'e.g. Electrician']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Trade / Job','model' => 'form.trade','placeholder' => 'e.g. Electrician']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginal3675552c19ef7b6d3be1947344c69a57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3675552c19ef7b6d3be1947344c69a57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.textarea','data' => ['label' => 'Message','model' => 'form.message','rows' => '4','required' => true,'placeholder' => 'Write your question here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Message','model' => 'form.message','rows' => '4','required' => true,'placeholder' => 'Write your question here']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3675552c19ef7b6d3be1947344c69a57)): ?>
<?php $attributes = $__attributesOriginal3675552c19ef7b6d3be1947344c69a57; ?>
<?php unset($__attributesOriginal3675552c19ef7b6d3be1947344c69a57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3675552c19ef7b6d3be1947344c69a57)): ?>
<?php $component = $__componentOriginal3675552c19ef7b6d3be1947344c69a57; ?>
<?php unset($__componentOriginal3675552c19ef7b6d3be1947344c69a57); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal3353065aa04adf785074343a19ad8d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3353065aa04adf785074343a19ad8d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.honeypot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.honeypot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3353065aa04adf785074343a19ad8d80)): ?>
<?php $attributes = $__attributesOriginal3353065aa04adf785074343a19ad8d80; ?>
<?php unset($__attributesOriginal3353065aa04adf785074343a19ad8d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3353065aa04adf785074343a19ad8d80)): ?>
<?php $component = $__componentOriginal3353065aa04adf785074343a19ad8d80; ?>
<?php unset($__componentOriginal3353065aa04adf785074343a19ad8d80); ?>
<?php endif; ?>

            <button type="submit" class="btn btn-red w-full" wire:loading.attr="disabled" wire:target="submit">
              <span wire:loading.remove wire:target="submit">Send Message</span>
              <span wire:loading wire:target="submit">Sending…</span>
            </button>
          </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </div>
  </section>

  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mapUrl): ?>
    <section class="bg-pk-bg py-16 md:py-20">
      <div class="mx-auto w-[92%] max-w-6xl text-center">
        <span class="eyebrow">Find Us</span>
        <h2 class="title mb-8">Our Location</h2>
        <iframe src="<?php echo e($mapUrl); ?>" title="Our location" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="h-80 w-full rounded-2xl border-0 shadow-xl"></iframe>
      </div>
    </section>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/forms/contact.blade.php ENDPATH**/ ?>