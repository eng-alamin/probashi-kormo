<?php use \App\Support\SafeRoute; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => 'Privacy Policy','crumbs' => [['Privacy Policy', null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Privacy Policy','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Privacy Policy', null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<section class="py-16 md:py-20"><div class="mx-auto w-[92%] max-w-3xl">
  <h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Information we collect</h2><p class="text-slate-600">When you fill in our contact or application form, we receive details such as your name, phone number, age, address, passport status, education and experience.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">How we use it</h2><p class="text-slate-600">We use your information only to contact you, to match you with suitable jobs or training, and to process your application.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Sharing</h2><p class="text-slate-600">We share your information with employers, authorities or partners only when needed for your job application and visa process.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Your choices</h2><p class="text-slate-600">You can ask us to correct or delete your information at any time by contacting us.</p><h2 class="mb-2 mt-8 text-xl font-bold text-pk-dark">Contact</h2><p class="text-slate-600">For any question about this policy, contact us at info@probashikormo.com.</p>
</div></section>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/privacy-policy.blade.php ENDPATH**/ ?>