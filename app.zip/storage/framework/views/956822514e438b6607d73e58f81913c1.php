<div>
  <div class="page-head">
    <div><h2>News &amp; Notice</h2><p>Announcements shown on the website news page</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.create')): ?>
      <a href="<?php echo e(route('admin.news.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New post</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search title" aria-label="Search news">
      </label>
      <select class="form-select" wire:model.live="state" aria-label="Filter by status">
        <option value="">All posts</option>
        <option value="live">Live</option>
        <option value="scheduled">Scheduled</option>
        <option value="draft">Draft</option>
      </select>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($posts->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-megaphone-fill"></i></div>
        <h6>No posts found</h6>
        <p>Write a post to share news or a notice on the website.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Post</th>
              <th scope="col">Publish date</th>
              <th scope="col">Status</th>
              <th scope="col">Published</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <?php ($isDraft = ! $post->is_published || $post->published_at === null); ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'post-'.e($post->id).''; ?>wire:key="post-<?php echo e($post->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($post->cover_image_path): ?>
                      <img class="cell-thumb" src="<?php echo e(\App\Support\ImageStore::url($post->cover_image_path)); ?>" alt="" loading="lazy">
                    <?php else: ?>
                      <span class="cell-avatar" aria-hidden="true"><i class="bi bi-megaphone-fill"></i></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div>
                      <div class="cell-title"><?php echo e($post->title); ?></div>
                      <div class="cell-sub">/news/<?php echo e($post->slug); ?></div>
                    </div>
                  </div>
                </td>
                <td data-label="Publish date"><?php echo e($post->published_at?->format('d M Y, h:i A') ?? '—'); ?></td>
                <td data-label="Status">
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isDraft): ?>
                    <span class="status-pill status-suspended">Draft</span>
                  <?php elseif($post->published_at->isFuture()): ?>
                    <span class="status-pill status-trial">Scheduled</span>
                  <?php else: ?>
                    <span class="status-pill status-active">Live</span>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td data-label="Published">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.update')): ?>
                    <button type="button" class="status-toggle" wire:click="togglePublished(<?php echo e($post->id); ?>)" role="switch" aria-checked="<?php echo e($post->is_published ? 'true' : 'false'); ?>" aria-label="Publish <?php echo e($post->title); ?>"><span class="switch <?php echo e($post->is_published ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($post->is_published ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.news.edit', $post)); ?>" aria-label="Edit <?php echo e($post->title); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($post->id); ?>)" aria-label="Delete <?php echo e($post->title); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($posts->links('pagination.admin')); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this post?</h4>
      <p class="modal-sub">It will be removed from the website, along with its cover image. To hide it temporarily, switch Published off instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/news/index.blade.php ENDPATH**/ ?>