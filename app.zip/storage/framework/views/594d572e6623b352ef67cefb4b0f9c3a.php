<?php use \App\Support\SafeRoute; ?>
<?php use \App\Support\Site; ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php
  $seoTitle = (isset($title) ? $title.' | ' : '').config('site.name');
  $seoDescription = ! empty($description) ? $description : config('site.name').' – '.config('site.tagline');
  $seoImage = ! empty($image) ? $image : asset('site/img/logo.jpg');
?>
<title><?php echo e($seoTitle); ?></title>
<meta name="description" content="<?php echo e($seoDescription); ?>">
<link rel="canonical" href="<?php echo e(url()->current()); ?>">
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($noindex)): ?>
<meta name="robots" content="noindex, follow">
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<meta property="og:site_name" content="<?php echo e(config('site.name')); ?>">
<meta property="og:type" content="<?php echo e($ogType ?? 'website'); ?>">
<meta property="og:title" content="<?php echo e($seoTitle); ?>">
<meta property="og:description" content="<?php echo e($seoDescription); ?>">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:image" content="<?php echo e($seoImage); ?>">
<meta name="twitter:card" content="<?php echo e(! empty($image) ? 'summary_large_image' : 'summary'); ?>">
<meta name="twitter:title" content="<?php echo e($seoTitle); ?>">
<meta name="twitter:description" content="<?php echo e($seoDescription); ?>">
<meta name="twitter:image" content="<?php echo e($seoImage); ?>">
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($jsonLd)): ?>
<script type="application/ld+json"><?php echo \App\Support\Seo::json($jsonLd); ?></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<link rel="icon" href="<?php echo e(asset('site/img/logo.jpg')); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('site/css/tailwind.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/css/extra.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/css/glass.css')); ?>">
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="bg-white font-sans leading-relaxed text-slate-800">

<!-- Topbar (shows only the details that are filled in) -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone() || Site::email()): ?>
<div class="bg-pk-dark py-2 text-xs text-green-100">
  <div class="mx-auto flex w-[92%] max-w-6xl flex-wrap justify-center gap-x-6 gap-y-1 sm:justify-between">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone()): ?><a href="<?php echo e(Site::phoneHref()); ?>" class="hover:text-white">📞 <?php echo e(Site::phone()); ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::email()): ?><a href="mailto:<?php echo e(Site::email()); ?>" class="hover:text-white">✉ <?php echo e(Site::email()); ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<!-- Header -->
<header class="sticky top-0 z-50 bg-white shadow">
  <div class="relative mx-auto flex h-[74px] w-[92%] max-w-6xl items-center justify-between">
    <a href="<?php echo e(SafeRoute::url('home')); ?>" class="flex items-center gap-2.5 font-bold leading-tight text-pk-dark">
      <img src="<?php echo e(asset('site/img/logo.jpg')); ?>" alt="<?php echo e(config('site.short_name')); ?> logo" class="h-12 w-12 rounded-full object-cover">
      <span><?php echo e(config('site.short_name')); ?><small class="block text-[.72rem] font-medium text-pk-red">Overseas &amp; Travels</small></span>
    </a>
    <button id="burger" type="button" aria-label="Menu" aria-expanded="false" class="text-3xl text-pk-dark lg:hidden">☰</button>
    <nav id="menu" class="absolute left-0 right-0 top-[74px] hidden bg-white shadow-xl lg:static lg:block lg:shadow-none">
      <ul class="flex flex-col gap-0 px-2 py-3 lg:flex-row lg:items-center lg:gap-6 lg:p-0">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = config('site.nav'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! empty($item['cta'])): ?>
            <li class="py-2.5 lg:py-0"><a href="<?php echo e(SafeRoute::url($item['route'])); ?>" class="btn btn-red !px-5 !py-2"><?php echo e($item['label']); ?></a></li>
          <?php else: ?>
            <li class="border-b border-slate-100 py-2.5 lg:border-0 lg:py-0"><a href="<?php echo e(SafeRoute::url($item['route'])); ?>" class="nav-link <?php echo e(request()->routeIs($item['route']) ? 'border-pk-red text-pk-red' : ''); ?>"><?php echo e($item['label']); ?></a></li>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<?php echo e($slot); ?>


<!-- Footer -->
<footer class="bg-[#0b2a21] pt-14 text-[.92rem] text-emerald-100/70">
  <div class="mx-auto grid w-[92%] max-w-6xl gap-9 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
    <div><h4 class="mb-3.5 font-semibold text-white"><?php echo e(config('site.name')); ?></h4><p><?php echo e(config('site.tagline')); ?></p></div>
    <div>
      <h4 class="mb-3.5 font-semibold text-white">Quick Links</h4>
      <ul class="space-y-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = config('site.footer.quick'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <li><a class="hover:text-white" href="<?php echo e(SafeRoute::url($item['route'])); ?>"><?php echo e($item['label']); ?></a></li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </ul>
    </div>
    <div>
      <h4 class="mb-3.5 font-semibold text-white">More</h4>
      <ul class="space-y-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = config('site.footer.more'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <li><a class="hover:text-white" href="<?php echo e(SafeRoute::url($item['route'])); ?>"><?php echo e($item['label']); ?></a></li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <li><a class="hover:text-white" href="<?php echo e(config('site.facebook')); ?>" target="_blank" rel="noopener">Facebook</a></li>
      </ul>
    </div>
    <div>
      <h4 class="mb-3.5 font-semibold text-white">Contact</h4>
      <ul class="space-y-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::address()): ?><li>📍 <?php echo e(Site::address()); ?></li><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone()): ?><li>📞 <a class="hover:text-white" href="<?php echo e(Site::phoneHref()); ?>"><?php echo e(Site::phone()); ?></a></li><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::email()): ?><li>✉ <a class="hover:text-white" href="mailto:<?php echo e(Site::email()); ?>"><?php echo e(Site::email()); ?></a></li><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <li><a class="hover:text-white" href="<?php echo e(SafeRoute::url('contact')); ?>">Send us a message →</a></li>
      </ul>
    </div>
  </div>
  <div class="mt-10 border-t border-emerald-900 py-4 text-center text-sm">
    © <span data-year><?php echo e(now()->year); ?></span> <?php echo e(config('site.name')); ?>. All rights reserved.
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = config('site.footer.legal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
      &nbsp;|&nbsp; <a class="hover:text-white" href="<?php echo e(SafeRoute::url($item['route'])); ?>"><?php echo e($item['label']); ?></a>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
  </div>
</footer>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::whatsappUrl()): ?>
<a href="<?php echo e(Site::whatsappUrl()); ?>" target="_blank" rel="noopener" aria-label="WhatsApp" class="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-[#25d366] text-2xl text-white shadow-xl">💬</a>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<script src="<?php echo e(asset('site/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/layouts/site.blade.php ENDPATH**/ ?>