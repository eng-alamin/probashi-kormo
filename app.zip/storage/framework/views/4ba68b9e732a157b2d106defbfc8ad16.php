<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasPages()): ?>
  <nav class="pager" aria-label="Pagination">
    <span class="pager-info"><?php echo e($paginator->firstItem()); ?>–<?php echo e($paginator->lastItem()); ?> of <?php echo e($paginator->total()); ?></span>
    <span class="pager-btns">
      <button type="button" class="btn btn-ghost btn-sm" wire:click="previousPage('<?php echo e($paginator->getPageName()); ?>')" <?php if($paginator->onFirstPage()): echo 'disabled'; endif; ?>><i class="bi bi-chevron-left" aria-hidden="true"></i> Prev</button>
      <span class="pager-page">Page <?php echo e($paginator->currentPage()); ?> / <?php echo e($paginator->lastPage()); ?></span>
      <button type="button" class="btn btn-ghost btn-sm" wire:click="nextPage('<?php echo e($paginator->getPageName()); ?>')" <?php if(! $paginator->hasMorePages()): echo 'disabled'; endif; ?>>Next <i class="bi bi-chevron-right" aria-hidden="true"></i></button>
    </span>
  </nav>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/pagination/admin.blade.php ENDPATH**/ ?>