<div>
  <div class="page-head">
    <div><h2>Gallery</h2><p>Photos shown on the website gallery page</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery.create')): ?>
      <a href="<?php echo e(route('admin.gallery.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> Add photos</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search title or caption" aria-label="Search photos">
      </label>
      <select class="form-select" wire:model.live="category" aria-label="Filter by category">
        <option value="">All categories</option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <option value="<?php echo e($c->value); ?>"><?php echo e($c->label()); ?></option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <option value="none">No category</option>
      </select>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($items->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-images"></i></div>
        <h6>No photos found</h6>
        <p>Add photos and they will appear on the website gallery page.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Photo</th>
              <th scope="col">Category</th>
              <th scope="col">Order</th>
              <th scope="col">Visible</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'photo-'.e($item->id).''; ?>wire:key="photo-<?php echo e($item->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <img class="cell-thumb" src="<?php echo e(\App\Support\ImageStore::url($item->image_path)); ?>" alt="<?php echo e($item->title ?: 'Gallery photo'); ?>" loading="lazy">
                    <div>
                      <div class="cell-title"><?php echo e($item->title ?: 'Untitled photo'); ?></div>
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->caption): ?><div class="cell-sub"><?php echo e(\Illuminate\Support\Str::limit($item->caption, 60)); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                  </div>
                </td>
                <td data-label="Category"><?php echo e($item->category?->label() ?? '—'); ?></td>
                <td data-label="Order"><?php echo e($item->sort_order); ?></td>
                <td data-label="Visible">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery.update')): ?>
                    <button type="button" class="status-toggle" wire:click="toggleActive(<?php echo e($item->id); ?>)" role="switch" aria-checked="<?php echo e($item->is_active ? 'true' : 'false'); ?>" aria-label="Show this photo on website"><span class="switch <?php echo e($item->is_active ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($item->is_active ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.gallery.edit', $item)); ?>" aria-label="Edit photo"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($item->id); ?>)" aria-label="Delete photo"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($items->links('pagination.admin')); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this photo?</h4>
      <p class="modal-sub">The photo file is removed from the server too. To hide it temporarily, use the Visible switch instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/gallery/index.blade.php ENDPATH**/ ?>