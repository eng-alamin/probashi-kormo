<?php use \App\Support\SafeRoute; ?>
<?php use \App\Support\Site; ?>
<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => 'Apply Online','crumbs' => [['Apply', null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Apply Online','crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Apply', null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto w-[92%] max-w-3xl">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sent): ?>
        <div class="rounded-2xl bg-white p-8 text-center shadow-xl shadow-green-900/10 md:p-10">
          <div class="mb-3 text-6xl">✅</div>
          <h2 class="title">Thank You!</h2>
          <p class="mb-2 text-slate-600">We have received your application. Our team will contact you on the phone number you gave.</p>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($reference): ?>
            <p class="mb-5 text-sm text-slate-500">Your reference: <b class="text-pk-dark"><?php echo e($reference); ?></b></p>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          <div class="flex flex-wrap justify-center gap-3">
            <a href="<?php echo e(SafeRoute::url('jobs')); ?>" class="btn btn-green">See Jobs</a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::whatsappUrl()): ?>
              <a href="<?php echo e(Site::whatsappUrl()); ?>" target="_blank" rel="noopener" class="btn btn-red">Message us on WhatsApp</a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          </div>
        </div>
      <?php else: ?>
        <div class="mb-8 text-center">
          <span class="eyebrow">Start Here</span>
          <h2 class="title">Job Application Form</h2>
          <p class="lead mx-auto">Fill in your details and send. Our team will call you to explain the next steps.</p>
        </div>

        <form wire:submit="submit" class="space-y-5 rounded-2xl bg-white p-6 shadow-xl shadow-green-900/10 md:p-8">
          <div class="grid gap-5 sm:grid-cols-2">
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Full Name','model' => 'form.full_name','required' => true,'placeholder' => 'Your name','autocomplete' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Full Name','model' => 'form.full_name','required' => true,'placeholder' => 'Your name','autocomplete' => 'name']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Phone Number','model' => 'form.phone','type' => 'tel','required' => true,'placeholder' => '01XXXXXXXXX','autocomplete' => 'tel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Phone Number','model' => 'form.phone','type' => 'tel','required' => true,'placeholder' => '01XXXXXXXXX','autocomplete' => 'tel']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
          </div>

          <div class="grid gap-5 sm:grid-cols-2">
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Age','model' => 'form.age','type' => 'number','required' => true,'placeholder' => 'e.g. 25','inputmode' => 'numeric']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Age','model' => 'form.age','type' => 'number','required' => true,'placeholder' => 'e.g. 25','inputmode' => 'numeric']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'District / Address','model' => 'form.district','required' => true,'placeholder' => 'Your district']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'District / Address','model' => 'form.district','required' => true,'placeholder' => 'Your district']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
          </div>

          <div class="grid gap-5 sm:grid-cols-2">
            <?php if (isset($component)) { $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.select','data' => ['label' => 'Do you have a passport?','model' => 'form.passport_status','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Do you have a passport?','model' => 'form.passport_status','required' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

              <option value="">Select</option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $passportOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $attributes = $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $component = $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.select','data' => ['label' => 'Education','model' => 'form.education']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Education','model' => 'form.education']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

              <option value="">Select</option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($level); ?>"><?php echo e($level); ?></option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $attributes = $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $component = $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
          </div>

          <div class="grid gap-5 sm:grid-cols-2">
            <?php if (isset($component)) { $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.select','data' => ['label' => 'Preferred Country','model' => 'form.country_id','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Preferred Country','model' => 'form.country_id','required' => true]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

              <option value="">Select country</option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
              <option value="other">Other / Not sure</option>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $attributes = $__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__attributesOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55)): ?>
<?php $component = $__componentOriginal7277eb1a6cd651ee2306fa2522a68a55; ?>
<?php unset($__componentOriginal7277eb1a6cd651ee2306fa2522a68a55); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Experience (years)','model' => 'form.experience','placeholder' => 'e.g. 2 years']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Experience (years)','model' => 'form.experience','placeholder' => 'e.g. 2 years']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
          </div>

          <?php if (isset($component)) { $__componentOriginalee8575ac7ae80e2f656884a30289c8fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.field','data' => ['label' => 'Job / Trade','model' => 'form.trade','required' => true,'placeholder' => 'e.g. Electrician']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Job / Trade','model' => 'form.trade','required' => true,'placeholder' => 'e.g. Electrician']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $attributes = $__attributesOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__attributesOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb)): ?>
<?php $component = $__componentOriginalee8575ac7ae80e2f656884a30289c8fb; ?>
<?php unset($__componentOriginalee8575ac7ae80e2f656884a30289c8fb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal3675552c19ef7b6d3be1947344c69a57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3675552c19ef7b6d3be1947344c69a57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.textarea','data' => ['label' => 'Message','model' => 'form.message','rows' => '3','placeholder' => 'Anything else you want to tell us']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Message','model' => 'form.message','rows' => '3','placeholder' => 'Anything else you want to tell us']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3675552c19ef7b6d3be1947344c69a57)): ?>
<?php $attributes = $__attributesOriginal3675552c19ef7b6d3be1947344c69a57; ?>
<?php unset($__attributesOriginal3675552c19ef7b6d3be1947344c69a57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3675552c19ef7b6d3be1947344c69a57)): ?>
<?php $component = $__componentOriginal3675552c19ef7b6d3be1947344c69a57; ?>
<?php unset($__componentOriginal3675552c19ef7b6d3be1947344c69a57); ?>
<?php endif; ?>

          <?php if (isset($component)) { $__componentOriginal3353065aa04adf785074343a19ad8d80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3353065aa04adf785074343a19ad8d80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.honeypot','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.honeypot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3353065aa04adf785074343a19ad8d80)): ?>
<?php $attributes = $__attributesOriginal3353065aa04adf785074343a19ad8d80; ?>
<?php unset($__attributesOriginal3353065aa04adf785074343a19ad8d80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3353065aa04adf785074343a19ad8d80)): ?>
<?php $component = $__componentOriginal3353065aa04adf785074343a19ad8d80; ?>
<?php unset($__componentOriginal3353065aa04adf785074343a19ad8d80); ?>
<?php endif; ?>

          <button type="submit" class="btn btn-red w-full" wire:loading.attr="disabled" wire:target="submit">
            <span wire:loading.remove wire:target="submit">Send Application</span>
            <span wire:loading wire:target="submit">Sending…</span>
          </button>
          <p class="text-center text-xs text-slate-500">By sending, you agree to our <a href="<?php echo e(SafeRoute::url('privacy-policy')); ?>" class="text-pk-red hover:underline">Privacy Policy</a>. Never share your passport number on this form.</p>
        </form>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </section>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/forms/apply.blade.php ENDPATH**/ ?>