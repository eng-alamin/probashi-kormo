<div>
  <div class="page-head">
    <div><h2>Jobs</h2><p>Openings shown on the website</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobs.create')): ?>
      <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New job</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search job title" aria-label="Search jobs">
      </label>
      <select class="form-select" wire:model.live="country" aria-label="Filter by country">
        <option value="">All countries</option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </select>
      <select class="form-select" wire:model.live="state" aria-label="Filter by state">
        <option value="">All jobs</option>
        <option value="open">Open</option>
        <option value="closed">Closed (deadline passed)</option>
        <option value="inactive">Hidden</option>
      </select>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($jobs->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-briefcase-fill"></i></div>
        <h6>No jobs found</h6>
        <p>Add a job and it will appear on the website jobs page.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Job</th>
              <th scope="col">Country</th>
              <th scope="col">Deadline</th>
              <th scope="col">Applications</th>
              <th scope="col">Status</th>
              <th scope="col">Visible</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <?php ($expired = $job->deadline !== null && $job->deadline->lt(today())); ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'job-'.e($job->id).''; ?>wire:key="job-<?php echo e($job->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-title"><?php echo e($job->title); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($job->is_featured): ?> <i class="bi bi-star-fill" style="color:var(--citrus); font-size:.75rem;" title="Featured" aria-label="Featured"></i><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></div>
                  <div class="cell-sub"><?php echo e($job->category ?: '—'); ?></div>
                </td>
                <td data-label="Country"><?php echo e($job->country?->name ?? '—'); ?></td>
                <td data-label="Deadline"><?php echo e($job->deadline?->format('d M Y') ?? '—'); ?></td>
                <td data-label="Applications"><?php echo e($job->applications_count); ?></td>
                <td data-label="Status">
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $job->is_active): ?>
                    <span class="status-pill status-suspended">Hidden</span>
                  <?php elseif($expired): ?>
                    <span class="status-pill status-past">Closed</span>
                  <?php else: ?>
                    <span class="status-pill status-active">Open</span>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
                <td data-label="Visible">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobs.update')): ?>
                    <button type="button" class="status-toggle" wire:click="toggleActive(<?php echo e($job->id); ?>)" role="switch" aria-checked="<?php echo e($job->is_active ? 'true' : 'false'); ?>" aria-label="Show <?php echo e($job->title); ?> on website"><span class="switch <?php echo e($job->is_active ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($job->is_active ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobs.update')): ?>
                      <button type="button" class="icon-action" wire:click="toggleFeatured(<?php echo e($job->id); ?>)" aria-pressed="<?php echo e($job->is_featured ? 'true' : 'false'); ?>" aria-label="Toggle featured for <?php echo e($job->title); ?>"><i class="bi <?php echo e($job->is_featured ? 'bi-star-fill' : 'bi-star'); ?>" aria-hidden="true"></i></button>
                      <a class="icon-action" href="<?php echo e(route('admin.jobs.edit', $job)); ?>" aria-label="Edit <?php echo e($job->title); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobs.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($job->id); ?>)" aria-label="Delete <?php echo e($job->title); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php echo e($jobs->links('pagination.admin')); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this job?</h4>
      <p class="modal-sub">It will disappear from the website. Applications already received are kept, only their link to this job is removed. To hide a job temporarily, use the Visible switch instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/jobs/index.blade.php ENDPATH**/ ?>