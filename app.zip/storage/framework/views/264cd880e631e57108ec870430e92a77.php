<div>
  <div class="page-head">
    <div><h2>Countries</h2><p>Destinations shown on the website</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('countries.create')): ?>
      <a href="<?php echo e(route('admin.countries.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New country</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search country" aria-label="Search countries">
      </label>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($countries->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-globe2"></i></div>
        <h6>No countries found</h6>
        <p>Add a country to show it on the website.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Country</th>
              <th scope="col">Order</th>
              <th scope="col">Jobs</th>
              <th scope="col">Visible</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'country-'.e($country->id).''; ?>wire:key="country-<?php echo e($country->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <span class="cell-avatar" style="font-size:1.1rem;" aria-hidden="true"><?php echo e($country->flag ?: mb_strtoupper(mb_substr($country->name, 0, 1))); ?></span>
                    <div>
                      <div class="cell-title"><?php echo e($country->name); ?></div>
                      <div class="cell-sub">/countries/<?php echo e($country->slug); ?></div>
                    </div>
                  </div>
                </td>
                <td data-label="Order"><?php echo e($country->sort_order); ?></td>
                <td data-label="Jobs"><?php echo e($country->job_posts_count); ?></td>
                <td data-label="Visible">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('countries.update')): ?>
                    <button type="button" class="status-toggle" wire:click="toggleActive(<?php echo e($country->id); ?>)" role="switch" aria-checked="<?php echo e($country->is_active ? 'true' : 'false'); ?>" aria-label="Show <?php echo e($country->name); ?> on website"><span class="switch <?php echo e($country->is_active ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($country->is_active ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('countries.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.countries.edit', $country)); ?>" aria-label="Edit <?php echo e($country->name); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('countries.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($country->id); ?>)" aria-label="Delete <?php echo e($country->name); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this country?</h4>
      <p class="modal-sub">A country that still has jobs cannot be deleted. To remove it from the website without deleting, use the Visible switch.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/countries/index.blade.php ENDPATH**/ ?>