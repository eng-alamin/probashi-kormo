<?php use \App\Support\SafeRoute; ?>
<?php use \App\Support\Site; ?>
<?php
  $home = Site::home();
?>
<div>
  <!-- Hero -->
  <section class="relative overflow-hidden bg-gradient-to-br from-pk-dark to-pk-green pb-28 pt-16 text-white md:pb-32 md:pt-24">
    <div class="pointer-events-none absolute -bottom-28 -right-28 h-96 w-96 rounded-full bg-pk-red/35"></div>
    <div class="relative mx-auto grid w-[92%] max-w-6xl items-center gap-10 md:grid-cols-[1.2fr_.8fr]">
      <div class="order-2 text-center md:order-1 md:text-left">
        <h1 class="mb-4 text-4xl font-bold leading-tight md:text-5xl"><?php echo e($home['title']); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($home['highlight'])): ?> <span class="text-red-200"><?php echo e($home['highlight']); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></h1>
        <p class="mx-auto mb-8 max-w-xl text-green-50 md:mx-0"><?php echo e($home['text']); ?></p>
        <div class="flex flex-wrap justify-center gap-3.5 md:justify-start">
          <a href="<?php echo e(SafeRoute::url('apply')); ?>" class="btn btn-red">Apply Now</a>
          <a href="<?php echo e(SafeRoute::url('services')); ?>" class="btn btn-line">Our Services</a>
        </div>
      </div>
      <div class="order-1 justify-self-center md:order-2">
        <img src="<?php echo e(asset('site/img/logo.jpg')); ?>" alt="<?php echo e(config('site.short_name')); ?>" class="w-64 animate-bounce rounded-full shadow-2xl [animation-duration:4s] md:w-80">
      </div>
    </div>
  </section>

  <!-- Stats -->
  <section class="relative z-10 -mt-14">
    <div class="mx-auto grid w-[92%] max-w-6xl grid-cols-2 overflow-hidden rounded-2xl bg-white shadow-xl shadow-green-900/10 md:grid-cols-4">
      <?php
        $statClasses = [
          'border-b border-r border-slate-100 p-7 text-center md:border-b-0',
          'border-b border-slate-100 p-7 text-center md:border-b-0 md:border-r',
          'border-r border-slate-100 p-7 text-center',
          'p-7 text-center',
        ];
      ?>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $home['stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$value, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="<?php echo e($statClasses[$i]); ?>"><b class="block text-3xl text-pk-red"><?php echo e($value); ?></b><span class="text-sm text-slate-500"><?php echo e($label); ?></span></div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    </div>
  </section>

  <!-- Services -->
  <section class="py-16 md:py-20">
    <div class="reveal mx-auto w-[92%] max-w-6xl text-center">
      <span class="eyebrow">What We Do</span>
      <h2 class="title">Complete Overseas Employment Solutions</h2>
      <p class="lead mx-auto">From skill development to departure, we handle every step so you can focus on building your career.</p>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($services->isNotEmpty()): ?>
        <div class="mt-11 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e(route('services.show', $service)); ?>" class="card block">
              <div class="mb-3 text-4xl"><?php echo e($service->icon); ?></div>
              <h3 class="mb-2 text-lg font-semibold text-pk-dark"><?php echo e($service->title); ?></h3>
              <p class="text-[.95rem] text-slate-600"><?php echo e($service->summary); ?></p>
              <span class="mt-3 inline-block text-sm font-semibold text-pk-red">Learn more →</span>
            </a>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </section>

  <!-- Countries -->
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($countries->isNotEmpty()): ?>
    <section class="bg-pk-bg py-16 md:py-20">
      <div class="reveal mx-auto w-[92%] max-w-6xl text-center">
        <span class="eyebrow">Where We Send Workers</span>
        <h2 class="title">Countries We Work With</h2>
        <div class="mt-8 flex flex-wrap justify-center gap-3">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e(route('countries.show', $country)); ?>" class="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-pk-dark shadow-lg shadow-green-900/10 transition hover:text-pk-red"><?php echo e($country->flag); ?> <?php echo e($country->name); ?></a>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
      </div>
    </section>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

  <!-- Training -->
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($courses->isNotEmpty()): ?>
    <section class="py-16 md:py-20">
      <div class="reveal mx-auto w-[92%] max-w-6xl text-center">
        <span class="eyebrow">Train With Us</span>
        <h2 class="title">Skills That Get You Hired Abroad</h2>
        <div class="mt-11 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a href="<?php echo e(route('training.show', $course)); ?>" class="card block">
              <div class="mb-3 text-4xl"><?php echo e($course->icon); ?></div>
              <h3 class="mb-2 text-lg font-semibold text-pk-dark"><?php echo e($course->title); ?></h3>
              <p class="text-[.95rem] text-slate-600"><?php echo e($course->summary); ?></p>
            </a>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
      </div>
    </section>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

  <!-- CTA -->
  <section class="bg-gradient-to-r from-pk-red to-red-800 py-16 text-center text-white">
    <div class="reveal mx-auto w-[92%] max-w-6xl">
      <h2 class="mb-2 text-3xl font-bold md:text-4xl">Start Your Overseas Career Today</h2>
      <p class="mb-6 text-red-100">Talk to our team and take the first step.</p>
      <a href="<?php echo e(SafeRoute::url('contact')); ?>" class="btn btn-line">Contact Us</a>
    </div>
  </section>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/home.blade.php ENDPATH**/ ?>