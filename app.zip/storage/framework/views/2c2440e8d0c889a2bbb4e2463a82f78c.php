<div>
  <div class="page-head">
    <div><h2>Success Stories</h2><p>Worker stories shown on the website</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stories.create')): ?>
      <a href="<?php echo e(route('admin.stories.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New story</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search name or trade" aria-label="Search stories">
      </label>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($stories->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-trophy-fill"></i></div>
        <h6>No stories found</h6>
        <p>Add a story only with the worker's permission.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Person</th>
              <th scope="col">Country</th>
              <th scope="col">Order</th>
              <th scope="col">Visible</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'story-'.e($story->id).''; ?>wire:key="story-<?php echo e($story->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($story->photo_path): ?>
                      <img class="cell-thumb round" src="<?php echo e(\App\Support\ImageStore::url($story->photo_path)); ?>" alt="" loading="lazy">
                    <?php else: ?>
                      <span class="cell-avatar" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($story->name, 0, 1))); ?></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div>
                      <div class="cell-title"><?php echo e($story->name); ?></div>
                      <div class="cell-sub"><?php echo e($story->trade ?: '—'); ?></div>
                    </div>
                  </div>
                </td>
                <td data-label="Country"><?php echo e($story->country?->name ?? '—'); ?></td>
                <td data-label="Order"><?php echo e($story->sort_order); ?></td>
                <td data-label="Visible">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stories.update')): ?>
                    <button type="button" class="status-toggle" wire:click="togglePublished(<?php echo e($story->id); ?>)" role="switch" aria-checked="<?php echo e($story->is_published ? 'true' : 'false'); ?>" aria-label="Show <?php echo e($story->name); ?> on website"><span class="switch <?php echo e($story->is_published ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($story->is_published ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stories.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.stories.edit', $story)); ?>" aria-label="Edit <?php echo e($story->name); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stories.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($story->id); ?>)" aria-label="Delete <?php echo e($story->name); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($stories->links('pagination.admin')); ?>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this story?</h4>
      <p class="modal-sub">The story and photo are removed. To hide it temporarily, use the Visible switch instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/stories/index.blade.php ENDPATH**/ ?>