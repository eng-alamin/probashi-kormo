<div>
  <?php if (isset($component)) { $__componentOriginal5eb3b9868f58806844f7e122c48174c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5eb3b9868f58806844f7e122c48174c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.banner','data' => ['title' => $service->title,'crumbs' => [['Services', route('services')], [$service->title, null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->title),'crumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['Services', route('services')], [$service->title, null]])]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $attributes = $__attributesOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__attributesOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eb3b9868f58806844f7e122c48174c6)): ?>
<?php $component = $__componentOriginal5eb3b9868f58806844f7e122c48174c6; ?>
<?php unset($__componentOriginal5eb3b9868f58806844f7e122c48174c6); ?>
<?php endif; ?>

  <section class="py-16 md:py-20">
    <div class="mx-auto grid w-[92%] max-w-6xl gap-10 lg:grid-cols-[1.7fr_1fr]">
      <div class="space-y-10">
        <div class="reveal">
          <div class="mb-4 text-6xl"><?php echo e($service->icon); ?></div>
          <h2 class="mb-4 text-2xl font-bold text-pk-dark"><?php echo e($service->title); ?></h2>
          <p class="text-slate-600"><?php echo e($service->description ?: $service->summary); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'What We Do','text' => $service->what_we_do]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'What We Do','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->what_we_do)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3fa9b4043ecd5975bf40536c47efd811 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.checklist','data' => ['title' => 'What You Need to Bring','text' => $service->what_to_bring]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.checklist'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'What You Need to Bring','text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->what_to_bring)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $attributes = $__attributesOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__attributesOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811)): ?>
<?php $component = $__componentOriginal3fa9b4043ecd5975bf40536c47efd811; ?>
<?php unset($__componentOriginal3fa9b4043ecd5975bf40536c47efd811); ?>
<?php endif; ?>
      </div>
      <aside class="space-y-6">
        <div class="rounded-2xl bg-white p-6 shadow-lg shadow-green-900/10">
          <h3 class="mb-2 font-semibold text-pk-dark">Quick Info</h3>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Service','value' => $service->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Service','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($service->title)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Cost','value' => 'Explained in advance']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Cost','value' => 'Explained in advance']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.info-row','data' => ['label' => 'Support','value' => 'Start to finish']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.info-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Support','value' => 'Start to finish']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $attributes = $__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__attributesOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb)): ?>
<?php $component = $__componentOriginal2798dd3276bdc40d1c2aceb222e776eb; ?>
<?php unset($__componentOriginal2798dd3276bdc40d1c2aceb222e776eb); ?>
<?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.help-box','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.help-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $attributes = $__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__attributesOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c)): ?>
<?php $component = $__componentOriginale2d12a70f913ce59a8e1298913fb3c3c; ?>
<?php unset($__componentOriginale2d12a70f913ce59a8e1298913fb3c3c); ?>
<?php endif; ?>
      </aside>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal8e9a093eefd41e45845394149ea14be9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e9a093eefd41e45845394149ea14be9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.chips','data' => ['title' => 'Other Services','route' => 'services.show','items' => $others->map(fn ($s) => [$s->icon.' '.$s->title, $s->slug])->all()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.chips'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Other Services','route' => 'services.show','items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($others->map(fn ($s) => [$s->icon.' '.$s->title, $s->slug])->all())]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $attributes = $__attributesOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__attributesOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e9a093eefd41e45845394149ea14be9)): ?>
<?php $component = $__componentOriginal8e9a093eefd41e45845394149ea14be9; ?>
<?php unset($__componentOriginal8e9a093eefd41e45845394149ea14be9); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal106c39dd228b3992904670768e42d9e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal106c39dd228b3992904670768e42d9e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.cta','data' => ['title' => 'Have a Question? Ask Us.','text' => 'We will explain clearly, with no hidden costs.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Have a Question? Ask Us.','text' => 'We will explain clearly, with no hidden costs.']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $attributes = $__attributesOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__attributesOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal106c39dd228b3992904670768e42d9e3)): ?>
<?php $component = $__componentOriginal106c39dd228b3992904670768e42d9e3; ?>
<?php unset($__componentOriginal106c39dd228b3992904670768e42d9e3); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/pages/services/show.blade.php ENDPATH**/ ?>