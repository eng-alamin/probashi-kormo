<div>
  <div class="page-head">
    <div><h2>Training</h2><p>Courses shown on the website</p></div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trainings.create')): ?>
      <a href="<?php echo e(route('admin.trainings.create')); ?>" class="btn btn-cobalt btn-sm"><i class="bi bi-plus-lg" aria-hidden="true"></i> New course</a>
    <?php endif; ?>
  </div>

  <div class="glass panel">
    <div class="list-toolbar">
      <label class="search-box">
        <i class="bi bi-search" aria-hidden="true"></i>
        <input type="search" wire:model.live.debounce.300ms="search" placeholder="Search course" aria-label="Search courses">
      </label>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($courses->isEmpty()): ?>
      <div class="state-block">
        <div class="state-icon" aria-hidden="true"><i class="bi bi-mortarboard-fill"></i></div>
        <h6>No courses found</h6>
        <p>Add a course to show it on the website.</p>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table class="responsive-table">
          <thead>
            <tr>
              <th scope="col">Course</th>
              <th scope="col">Duration</th>
              <th scope="col">Fee</th>
              <th scope="col">Order</th>
              <th scope="col">Visible</th>
              <th scope="col"><span class="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
              <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'course-'.e($course->id).''; ?>wire:key="course-<?php echo e($course->id); ?>">
                <td class="cell-main-td">
                  <div class="cell-main">
                    <span class="cell-avatar" style="font-size:1.1rem;" aria-hidden="true"><?php echo e($course->icon ?: mb_strtoupper(mb_substr($course->title, 0, 1))); ?></span>
                    <div>
                      <div class="cell-title"><?php echo e($course->title); ?></div>
                      <div class="cell-sub">/training/<?php echo e($course->slug); ?></div>
                    </div>
                  </div>
                </td>
                <td data-label="Duration"><?php echo e($course->duration_weeks ? $course->duration_weeks.' weeks' : '—'); ?></td>
                <td data-label="Fee"><?php echo e($course->fee !== null ? '৳ '.number_format($course->fee) : '—'); ?></td>
                <td data-label="Order"><?php echo e($course->sort_order); ?></td>
                <td data-label="Visible">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trainings.update')): ?>
                    <button type="button" class="status-toggle" wire:click="toggleActive(<?php echo e($course->id); ?>)" role="switch" aria-checked="<?php echo e($course->is_active ? 'true' : 'false'); ?>" aria-label="Show <?php echo e($course->title); ?> on website"><span class="switch <?php echo e($course->is_active ? 'on' : ''); ?>"></span></button>
                  <?php else: ?>
                    <?php echo e($course->is_active ? 'Yes' : 'No'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <div class="row-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trainings.update')): ?>
                      <a class="icon-action" href="<?php echo e(route('admin.trainings.edit', $course)); ?>" aria-label="Edit <?php echo e($course->title); ?>"><i class="bi bi-pencil" aria-hidden="true"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trainings.delete')): ?>
                      <button type="button" class="icon-action danger" wire:click="confirmDelete(<?php echo e($course->id); ?>)" aria-label="Delete <?php echo e($course->title); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </div>

  <div class="modal-overlay <?php echo e($deletingId ? 'open' : ''); ?>" role="dialog" aria-modal="true" aria-labelledby="delTitle" <?php if(! $deletingId): ?> aria-hidden="true" <?php endif; ?>>
    <div class="modal-box">
      <div class="confirm-icon" aria-hidden="true"><i class="bi bi-trash"></i></div>
      <h4 id="delTitle">Delete this course?</h4>
      <p class="modal-sub">It will be removed from the website. To hide it temporarily, use the Visible switch instead.</p>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" wire:click="cancelDelete">Cancel</button>
        <button type="button" class="btn btn-danger" wire:click="delete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/livewire/admin/trainings/index.blade.php ENDPATH**/ ?>