<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['apply' => 'Apply Now']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['apply' => 'Apply Now']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php use \App\Support\SafeRoute; ?>
<?php use \App\Support\Site; ?>
<div class="rounded-2xl bg-gradient-to-br from-pk-green to-pk-dark p-6 text-white shadow-xl">
  <h3 class="mb-2 text-lg font-semibold">Need help?</h3>
  <p class="mb-4 text-sm text-green-100">Our team will explain everything clearly.<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Site::phone()): ?> 📞 <a href="<?php echo e(Site::phoneHref()); ?>" class="font-semibold hover:underline"><?php echo e(Site::phone()); ?></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></p>
  <a href="<?php echo e(SafeRoute::url('apply')); ?>" class="btn btn-red mb-3 block text-center"><?php echo e($apply); ?></a>
  <a href="<?php echo e(SafeRoute::url('contact')); ?>" class="btn btn-line block text-center">Contact Us</a>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/components/site/help-box.blade.php ENDPATH**/ ?>