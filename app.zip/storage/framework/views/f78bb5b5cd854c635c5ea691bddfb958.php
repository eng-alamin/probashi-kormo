<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'model', 'preview' => null, 'current' => null, 'hint' => null, 'removeModel' => null, 'shape' => 'rect']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'model', 'preview' => null, 'current' => null, 'hint' => null, 'removeModel' => null, 'shape' => 'rect']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
  $id = 'f-'.str_replace('.', '-', $model);
  $previewUrl = \App\Support\ImageStore::previewUrl($preview);
?>
<div class="form-field span-2">
  <label class="form-label" for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
  <div class="upload-box <?php echo e($errors->has($model) ? 'is-invalid' : ''); ?>">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($previewUrl): ?>
      <img class="upload-preview <?php echo e($shape); ?>" src="<?php echo e($previewUrl); ?>" alt="Selected image preview">
    <?php elseif($current): ?>
      <img class="upload-preview <?php echo e($shape); ?>" src="<?php echo e($current); ?>" alt="Current image">
    <?php else: ?>
      <div class="upload-empty <?php echo e($shape); ?>" aria-hidden="true"><i class="bi bi-image"></i></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="upload-controls">
      <input id="<?php echo e($id); ?>" type="file" wire:model="<?php echo e($model); ?>" accept="image/jpeg,image/png,image/webp" class="form-control">
      <div class="form-hint" wire:loading wire:target="<?php echo e($model); ?>">Uploading…</div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($removeModel && $current && ! $previewUrl): ?>
        <div class="form-check" style="margin-top:8px;">
          <input id="<?php echo e($id); ?>-remove" type="checkbox" wire:model="<?php echo e($removeModel); ?>" class="form-check-input">
          <label class="form-check-label" for="<?php echo e($id); ?>-remove">Remove the current image</label>
        </div>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </div>
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hint): ?><div class="form-hint"><?php echo e($hint); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="field-error show" role="alert"><i class="bi bi-exclamation-circle" aria-hidden="true"></i><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\probashi-kormo\resources\views/components/admin/image.blade.php ENDPATH**/ ?>